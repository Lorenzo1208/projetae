/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.entities;

/**
 *
 * @author user
 */
public class Client {
    private int ID;
    private String nom;
    private String email;
    private String phone;
    private String zip;
    private String adresseLine1;
    private String adressLine2;
    private String city;
    private int creditLimit;
    private String fax;
    private String state;
    private String discount;

    public Client(int ID, String nom, String email, String phone, String zip, String adresseLine1, String adressLine2, String city, int creditLimit, String fax, String state, String discount) {
        this.ID = ID;
        this.nom = nom;
        this.email = email;
        this.phone = phone;
        this.zip = zip;
        this.adresseLine1 = adresseLine1;
        this.adressLine2 = adressLine2;
        this.city = city;
        this.creditLimit = creditLimit;
        this.fax = fax;
        this.state = state;
        this.discount = discount;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getAdresseLine1() {
        return adresseLine1;
    }

    public void setAdresseLine1(String adresseLine1) {
        this.adresseLine1 = adresseLine1;
    }

    public String getAdressLine2() {
        return adressLine2;
    }

    public void setAdressLine2(String adressLine2) {
        this.adressLine2 = adressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(int creditLimit) {
        this.creditLimit = creditLimit;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    @Override
    public String toString() {
        return "Client{" + "ID=" + ID + ", nom=" + nom + ", email=" + email + ", phone=" + phone + ", zip=" + zip + ", adresseLine1=" + adresseLine1 + ", adressLine2=" + adressLine2 + ", city=" + city + ", creditLimit=" + creditLimit + ", fax=" + fax + ", state=" + state + ", discount=" + discount + '}';
    }
    

   
}
