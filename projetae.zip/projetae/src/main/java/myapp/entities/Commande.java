/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.entities;

import java.sql.Date;

/**
 *
 * @author user
 */
public class Commande {
   private int numero;
    private int customerId;
    private int productID;
    private int quantite;
    private double coutLivraison;
    private Date dateLivraison;
    private Date dateAchat;

    public Commande(int numero, int customerId, int productID, int quantite, double coutLivraison, Date dateLivraison, Date dateAchat, String compagnieLivraison) {
        this.numero = numero;
        this.customerId = customerId;
        this.productID = productID;
        this.quantite = quantite;
        this.coutLivraison = coutLivraison;
        this.dateLivraison = dateLivraison;
        this.dateAchat = dateAchat;
        this.compagnieLivraison = compagnieLivraison;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public double getCoutLivraison() {
        return coutLivraison;
    }

    public void setCoutLivraison(double coutLivraison) {
        this.coutLivraison = coutLivraison;
    }

    public Date getDateLivraison() {
        return dateLivraison;
    }

    public void setDateLivraison(Date dateLivraison) {
        this.dateLivraison = dateLivraison;
    }

    public Date getDateAchat() {
        return dateAchat;
    }

    public void setDateAchat(Date dateAchat) {
        this.dateAchat = dateAchat;
    }

    public String getCompagnieLivraison() {
        return compagnieLivraison;
    }

    public void setCompagnieLivraison(String compagnieLivraison) {
        this.compagnieLivraison = compagnieLivraison;
    }
    private String compagnieLivraison;

    @Override
    public String toString() {
        return "Commande{" + "numero=" + numero + ", customerId=" + customerId + ", productID=" + productID + ", quantite=" + quantite + ", coutLivraison=" + coutLivraison + ", dateLivraison=" + dateLivraison + ", dateAchat=" + dateAchat + ", compagnieLivraison=" + compagnieLivraison + '}';
    }
    
}
