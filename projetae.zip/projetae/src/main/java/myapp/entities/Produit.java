/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.entities;

/**
 *
 * @author user
 */
public class Produit {
  private int idProduit;
    private int idFabriquant;
    private String codeProduit;
    private double prixProduit;
    private int quantite;
    private double markup;
    private String disponibilite;
    private String description;   

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Produit other = (Produit) obj;
        if (this.idProduit != other.idProduit) {
            return false;
        }
        return true;
    }

    public Produit(int idProduit) {
        this.idProduit = idProduit;
    }

    @Override
    public String toString() {
        return "Produit{" + "idProduit=" + idProduit + ", idFabriquant=" + idFabriquant + ", codeProduit=" + codeProduit + ", prixProduit=" + prixProduit + ", quantite=" + quantite + ", markup=" + markup + ", disponibilie=" + disponibilite + ", description=" + description + '}';
    }

    public Produit(int idProduit, int idFabriquant, String codeProduit, double prixProduit, int quantite, double markup, String disponibilite, String description) {
        this.idProduit = idProduit;
        this.idFabriquant = idFabriquant;
        this.codeProduit = codeProduit;
        this.prixProduit = prixProduit;
        this.quantite = quantite;
        this.markup = markup;
        this.disponibilite = disponibilite;
        this.description = description;
    }

    public int getIdProduit() {
        return idProduit;
    }

    public void setIdProduit(int idProduit) {
        this.idProduit = idProduit;
    }

    public int getIdFabriquant() {
        return idFabriquant;
    }

    public void setIdFabriquant(int idFabriquant) {
        this.idFabriquant = idFabriquant;
    }

    public String getCodeProduit() {
        return codeProduit;
    }

    public void setCodeProduit(String codeProduit) {
        this.codeProduit = codeProduit;
    }

    public double getPrixProduit() {
        return prixProduit;
    }

    public void setPrixProduit(double prixProduit) {
        this.prixProduit = prixProduit;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public double getMarkup() {
        return markup;
    }

    public void setMarkup(double markup) {
        this.markup = markup;
    }

  
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDisponibilite() {
        return disponibilite;
    }

    public void setDisponibilite(String disponibilite) {
        this.disponibilite = disponibilite;
    }
}
