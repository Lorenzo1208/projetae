/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import myapp.entities.Client;

/**
 *
 * @author user
 */
public class DAOGestionClient implements IDAOGestionClient {
    Connection connection;
    public DAOGestionClient()throws SQLException
    {
     connection = DAOConnectionManager.getConnection();
    }
    @Override
    public Client chercher(String nom, String email) throws SQLException {
       
        Statement statement = connection.createStatement();
        ResultSet result = statement.executeQuery("select * from CUSTOMER WHERE NAME='"+nom+"'AND EMAIL='"+email+"'");
         Client client = null; 
        while(result.next())
        {
        //public Client(int ID, String nom, String email, String phone, String zip, String adresseLine1, String adressLine2, String city, int creditLimite, String fax, String state, String creditLimit) 
        client = new Client(
                result.getInt("CUSTOMER_ID"),
                result.getString("NAME"),
                result.getString("EMAIL"),
                result.getString("PHONE"),
                result.getString("ZIP"),
                result.getString("ADDRESSLINE1"),
                result.getString("ADDRESSLINE2"),
                result.getString("CITY"),
                result.getInt("CREDIT_LIMIT"),
                result.getString("FAX"),
                result.getString("STATE"),
                result.getString("DISCOUNT_CODE")
        );
        }
        return client;
    }
    
}
