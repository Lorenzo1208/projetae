/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Vector;
import myapp.entities.Client;
import myapp.entities.Commande;
import myapp.entities.Produit;

/**
 *
 * @author user
 */
public class TestDAO {
    public static void main(String [] args)
    {
        try{
    IDAOGestionClient dao = new DAOGestionClient();
    IDAOGestionProduit daoProduit = new DAOGestionProduit();
    IDAOGestionCommande daoCommande =new DAOGestionCommande();
    
    String nom="Jumbo Eagle Corp";
    String email="jumboeagle@example.com";
            Client c = dao.chercher(nom, email);
            System.out.println(c);
            Vector<Produit> liste = daoProduit.liste();
            Produit p = daoProduit.chercher(980001);
            System.out.println(liste);
            System.out.println(p);
            Vector<Commande> vCommande = daoCommande.liste(c.getID());
            System.out.println(vCommande);
            Commande com = new Commande(11,1,980001,1,100.0d,new Date(12022000L), new Date(13022000L),"test");
            int i = daoCommande.inserer(com);
        }
        catch(SQLException e)
        {
        e.printStackTrace();
        }
    }
}
