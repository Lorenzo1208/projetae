/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.dao;

import java.sql.SQLException;
import java.util.Vector;
import myapp.entities.Produit;

/**
 *
 * @author user
 */
public interface IDAOGestionProduit {
    public Vector<Produit> liste() throws SQLException;
    public Produit         chercher(int idProduit) throws SQLException;
}
