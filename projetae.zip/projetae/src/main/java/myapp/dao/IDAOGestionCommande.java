/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.dao;

import java.sql.SQLException;
import java.util.Vector;
import myapp.entities.Commande;

/**
 *
 * @author user
 */
public interface IDAOGestionCommande {
    public Vector<Commande> liste(int idClient) throws SQLException;
   public int inserer(Commande c) throws SQLException;
}
