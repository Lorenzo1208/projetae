/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import myapp.entities.Client;
import myapp.entities.Produit;

/**
 *
 * @author user
 */
public class DAOGestionProduit implements IDAOGestionProduit {

    Connection connection;

    public DAOGestionProduit() throws SQLException {
        connection = DAOConnectionManager.getConnection();
    }

    @Override
    public Vector<Produit> liste() throws SQLException {
        String query = "Select * from PRODUCT";
        Statement s = connection.createStatement();
        ResultSet rs = s.executeQuery(query);
        Vector<Produit> v = new Vector<Produit>();

        while (rs.next()) {
            int idProduit = rs.getInt("PRODUCT_ID");
            int manufacturerID = rs.getInt("MANUFACTURER_ID");
            int quantite = rs.getInt("QUANTITY_ON_HAND");
            double prix = rs.getDouble("PURCHASE_COST");
            double markup = rs.getDouble("MARKUP");
            String codeProduit = rs.getString("PRODUCT_CODE");
            String available = rs.getString("AVAILABLE");
            String desciption = rs.getString("DESCRIPTION");
            String description = rs.getString("DESCRIPTION");

            Produit p = new Produit(idProduit, manufacturerID, codeProduit, prix, quantite, markup, available, description);
           
            v.add(p);

        }

        return v;

    }

    @Override
    public Produit chercher(int idProduit) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet result = statement.executeQuery("select * from PRODUCT WHERE PRODUCT_ID=" + idProduit + "");
        
        result.next();
        int manufacturerID = result.getInt("MANUFACTURER_ID");
        int quantite = result.getInt("QUANTITY_ON_HAND");
        double prix = result.getDouble("PURCHASE_COST");
        double markup = result.getDouble("MARKUP");
        String codeProduit = result.getString("PRODUCT_CODE");
        String available = result.getString("AVAILABLE");
        String desciption = result.getString("DESCRIPTION");
        String description = result.getString("DESCRIPTION");
        Produit p = new Produit(idProduit, manufacturerID, codeProduit, prix, quantite, markup, available, description);

        return p;

    }
}
