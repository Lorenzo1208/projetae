/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import myapp.entities.Commande;

/**
 *
 * @author user
 */
public class DAOGestionCommande implements IDAOGestionCommande {

    Connection connection;

    public DAOGestionCommande() throws SQLException {
        connection = DAOConnectionManager.getConnection();
    }

    @Override
    public Vector<Commande> liste(int idClient) throws SQLException {

        String query = "Select * from PURCHASE_ORDER WHERE CUSTOMER_ID=" + idClient;
        Statement s = connection.createStatement();
        ResultSet rs = s.executeQuery(query);
        Vector<Commande> v = new Vector<Commande>();
       
       
        while (rs.next()) {

            int idCommande = rs.getInt("ORDER_NUM");
            int productID = rs.getInt("PRODUCT_ID");
            int quantite = rs.getInt("QUANTITY");
            double shippingCost = rs.getDouble("SHIPPING_COST");
            Date salesDate = rs.getDate("SALES_DATE");
            Date shippingDate = rs.getDate("SHIPPING_DATE");

            String company = rs.getString("FREIGHT_COMPANY");
            //public Commande(int numero, int customerId, int productUD, int quantite, double coutLivraison, Date dateLivraison, String compagnieLivraison) {
            Commande commande = new Commande(idCommande, idClient, productID, quantite, shippingCost, salesDate, shippingDate, company);
            v.add(commande);

        }

        return v;

    }

    public int inserer(Commande c) throws SQLException
    {
            Statement s = connection.createStatement();
            String query = "INSERT INTO PURCHASE_ORDER (ORDER_NUM,CUSTOMER_ID, PRODUCT_ID,QUANTITY,SHIPPING_COST,SALES_DATE, SHIPPING_DATE, FREIGHT_COMPANY) VALUES (" + c.getNumero() + "," + c.getCustomerId() + "," + c.getProductID() + "," + c.getQuantite() + "," + c.getCoutLivraison() + ",'" + c.getDateAchat() + "','" + c.getDateLivraison() + "','" + c.getCompagnieLivraison() + "')";
            System.out.println(query);
            int i = s.executeUpdate(query);
return i;
    }
    
}


