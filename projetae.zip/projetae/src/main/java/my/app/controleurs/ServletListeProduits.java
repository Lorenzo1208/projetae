/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.app.controleurs;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Vector;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import myapp.dao.DAOGestionCommande;
import myapp.dao.DAOGestionProduit;
import myapp.dao.IDAOGestionCommande;
import myapp.dao.IDAOGestionProduit;
import myapp.entities.Client;
import myapp.entities.Commande;
import myapp.entities.Produit;

/**
 *
 * @author user
 */
@WebServlet(name = "ServletListeProduits", urlPatterns = {"/ServletListeProduits"})
public class ServletListeProduits extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
        try{
            
            HttpSession maSession =request.getSession(false);
            if(maSession==null){
            response.sendRedirect("/projetae/FormulaireAuthentification.html");
            }
            else {
                IDAOGestionProduit daoGestionProduit = new DAOGestionProduit();
        Client client = (Client)maSession.getAttribute("client");
                Vector<Produit> listeProduit = daoGestionProduit.liste();
                maSession.setAttribute("listeProduit", listeProduit);
                getServletContext().getRequestDispatcher("/ListeProduitsEL.jsp").forward(request, response);
            }
        }
        catch(SQLException e)
        {
        response.sendRedirect("/projetae/Erreur.html");
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
