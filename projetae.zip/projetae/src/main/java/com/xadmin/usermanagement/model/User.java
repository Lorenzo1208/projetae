package com.xadmin.usermanagement.model;

/**
 * User.java
 * This is a model class represents a User entity
 * @author Ramesh Fadatare
 *
 */
public class User {
	protected int id;
	protected String nom;
	protected String email;
	protected String pays;
	
	public User() {
	}
	
	public User(String nom, String email, String pays) {
		super();
		this.nom = nom;
		this.email = email;
		this.pays = pays;
	}

	public User(int id, String nom, String email, String pays) {
		super();
		this.id = id;
		this.nom = nom;
		this.email = email;
		this.pays = pays;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return nom;
	}
	public void setName(String nom) {
		this.nom = nom;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCountry() {
		return pays;
	}
	public void setCountry(String pays) {
		this.pays = pays;
	}
}